﻿namespace MQTTnet.Protocol
{
    public enum MqttPubCompReasonCode
    {
        Success = 0,
        PacketIdentifierNotFound = 146
    }
}
