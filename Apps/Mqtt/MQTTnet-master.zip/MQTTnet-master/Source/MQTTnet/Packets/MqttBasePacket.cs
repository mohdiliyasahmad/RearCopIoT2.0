﻿namespace MQTTnet.Packets
{
    public abstract class MqttBasePacket
    {
    }
}
