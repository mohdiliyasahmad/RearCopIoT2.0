﻿namespace MQTTnet.Server
{
    public enum MqttClientDisconnectType
    {
        Clean,
        NotClean,
        Takeover
    }
}
