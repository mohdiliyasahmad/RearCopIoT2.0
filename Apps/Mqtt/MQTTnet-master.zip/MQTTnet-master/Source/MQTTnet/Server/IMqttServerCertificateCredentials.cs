namespace MQTTnet.Server
{
    public interface IMqttServerCertificateCredentials
    {
        string Password { get; }
    }
}
