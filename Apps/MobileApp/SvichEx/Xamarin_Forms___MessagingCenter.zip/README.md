---
name: Xamarin.Forms - MessagingCenter
description: Sample code for the Xamarin.Forms MessagingCenter doc.
page_type: sample
languages:
- csharp
products:
- xamarin
urlFragment: usingmessagingcenter
---
# Xamarin.Forms MessagingCenter

Sample code for the [Xamarin.Forms MessagingCenter](https://docs.microsoft.com/xamarin/xamarin-forms/app-fundamentals/messaging-center) doc.

