﻿using Xamarin.Forms;

namespace UsingMessagingCenter
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new MainPage();
        }
    }
}
